
        <?php include 'header.php';  ?>


        <div id="slider" class="slider-wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <img class="img-responsive" src="img/slider.jpg">
                    </div>
                </div>
            </div>
        </div>


        <div id="absolute" class="absolute-wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="wrapper-absolute">
                            <div class="absolute block">absolute</div>
                            <div class="relative block">relative</div>
                            <div class="fixed block">fixed</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div id="menupaieska" class="paieskamenu">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="green-background">
                            <div class="menu-wrappers">
                                <ul>
                                    <li><a href="#">pradinis</a></li>
                                    <li><a href="#">pradinis</a></li>
                                    <li><a href="#">pradinis</a></li>
                                    <li><a href="#">pradinis</a></li>
                                </ul>
                            </div>
                            <div class="search-wrappers">
                                <form class="musuforma" action="action_page.php">
                                    <input class="ivestis" type="text" placeholder="Search.." name="search">
                                    <button class="mygtukas" type="submit">Search</button>
                                </form>
                            </div>
                            <div class="clearinam"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div id="menupaieska" class="paieskamenu">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="green-background">
                            <div class="menu-wrappers">
                                <ul>
                                    <li><a href="#">pradinis</a></li>
                                    <li><a href="#">pradinis</a></li>
                                    <li><a href="#">pradinis</a></li>
                                    <li><a href="#">pradinis</a></li>
                                </ul>
                            </div>
                            <div class="search-wrappers">
                                <form class="musuforma-du" action="action_page.php">
                                    <input class="ivestis-du" type="text" placeholder="Search.." name="search">
                                    <button class="mygtukas-du" type="submit">Search</button>
                                </form>
                            </div>
                            <div class="clearinam"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div id="logotipai" class="logotips">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="logotips-wrapper">
                            <img src="img/1.jpg">
                            <img src="img/2.png">
                            <img src="img/3.jpg">
                            <img src="img/4.png">
                            <img src="img/5.png">
                            <img src="img/1.jpg">
                            <img src="img/2.png">
                            <img src="img/3.jpg">
                            <img src="img/4.png">
                            <img src="img/5.png">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div id="services" class="services-wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="services-inside-wrapper">
                            <a href="#" class="service-item">
                                <div class="service-image-wrapper">
                                    <img src="img/ernis-gyvulys.jpg">
                                </div>
                                <div class="service-texts-wrapper">
                                    <h2>Service title</h2>
                                    <p>Vestassapede et donec ut est libe ros sus et eget sed eget quisq ueta habitur augue</p>
                                </div>
                            </a>
                            <a href="#" class="service-item">
                                <div class="service-image-wrapper">
                                    <img src="img/ernis-gyvulys.jpg">
                                </div>
                                <div class="service-texts-wrapper">
                                    <h2>Service title</h2>
                                    <p>Vestassapede et donec ut est libe ros sus et eget sed eget quisq ueta habitur augue</p>
                                </div>
                            </a>
                            <a href="#" class="service-item">
                                <div class="service-image-wrapper">
                                    <img src="img/ernis-gyvulys.jpg">
                                </div>
                                <div class="service-texts-wrapper">
                                    <h2>Service title</h2>
                                    <p>Vestassapede et donec ut est libe ros sus et eget sed eget quisq ueta habitur augue</p>
                                </div>
                            </a>
                            <a href="#" class="service-item">
                                <div class="service-image-wrapper">
                                    <img src="img/ernis-gyvulys.jpg">
                                </div>
                                <div class="service-texts-wrapper">
                                    <h2>Service title</h2>
                                    <p>Vestassapede et donec ut est libe ros sus et eget sed eget quisq ueta habitur augue</p>
                                </div>
                            </a>
                            <div class="clearfix"></div>

                        </div>
                    </div>
                </div>
            </div>
        </div>





        <div id="lateest" class="work">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="latest-heading-wrapper">
                            <div class="heading-line-helper">
                                <h2>Latest work</h2>
                                <div class="linija"></div>
                            </div> 
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="latest-items-wrapper">
                            <a href="#" class="latest-item">
                                <div class="latest-item-img">
                                    <img src="img/katinukas-gyvunelis.jpg">
                                </div>
                                <h4>Heading text extra</h4>
                            </a>
                            <a href="#" class="latest-item">
                                <div class="latest-item-img">
                                    <img src="img/katinukas-gyvunelis.jpg">
                                </div>
                                <h4>Heading text extra</h4>
                            </a>
                            <a href="#" class="latest-item">
                                <div class="latest-item-img">
                                    <img src="img/katinukas-gyvunelis.jpg">
                                </div>
                                <h4>Heading text extra</h4>
                            </a>


                            <a href="#" class="latest-item">
                                <div class="latest-item-img">
                                    <img src="img/katinukas-gyvunelis.jpg">
                                </div>
                                <h4>Heading text extra</h4>
                            </a>
                            <a href="#" class="latest-item">
                                <div class="latest-item-img">
                                    <img src="img/katinukas-gyvunelis.jpg">
                                </div>
                                <h4>Heading text extra</h4>
                            </a>
                            <a href="#" class="latest-item">
                                <div class="latest-item-img">
                                    <img src="img/katinukas-gyvunelis.jpg">
                                </div>
                                <h4>Heading text extra</h4>
                            </a>

                      
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php include 'footer.php';?>
        
