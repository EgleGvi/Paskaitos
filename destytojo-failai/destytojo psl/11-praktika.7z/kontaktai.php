
        <?php include 'header.php';?>
        <div>
            <h1>Kontaktai</h1>
            <p>Mano el paštas</p>
            <p>linas@ernis.lt</p>

            <p>Mano el paštas</p>
            <p>Mano el paštas</p>
        </div>
        <?php include 'footer.php';?>
