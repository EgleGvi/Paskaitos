




        <footer class="footer">
            visos teisės saugomos "Ernis" xxxxxxxxxx
        </footer>
    </body>
</html>