
        <?php include 'header.php';  ?>


        <div id="slider" class="slider-wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <img class="img-responsive" src="img/slider.jpg">
                    </div>
                </div>
            </div>
        </div>


        <div id="services" class="services-wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="services-inside-wrapper">
                            <a class="service-item">
                                <div class="service-image-wrapper">
                                    <img src="img/ernis-gyvulys.jpg">
                                </div>
                                <div class="service-texts-wrapper">
                                    <h2>Service title</h2>
                                    <p>Vestassapede et donec ut est libe ros sus et eget sed eget quisq ueta habitur augue</p>
                                </div>
                            </a>
                            <a class="service-item">
                                <div class="service-image-wrapper">
                                    <img src="img/ernis-gyvulys.jpg">
                                </div>
                                <div class="service-texts-wrapper">
                                    <h2>Service title</h2>
                                    <p>Vestassapede et donec ut est libe ros sus et eget sed eget quisq ueta habitur augue</p>
                                </div>
                            </a>
                            <a class="service-item">
                                <div class="service-image-wrapper">
                                    <img src="img/ernis-gyvulys.jpg">
                                </div>
                                <div class="service-texts-wrapper">
                                    <h2>Service title</h2>
                                    <p>Vestassapede et donec ut est libe ros sus et eget sed eget quisq ueta habitur augue</p>
                                </div>
                            </a>
                            <a class="service-item">
                                <div class="service-image-wrapper">
                                    <img src="img/ernis-gyvulys.jpg">
                                </div>
                                <div class="service-texts-wrapper">
                                    <h2>Service title</h2>
                                    <p>Vestassapede et donec ut est libe ros sus et eget sed eget quisq ueta habitur augue</p>
                                </div>
                            </a>
                            <div class="clearfix"></div>

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php include 'footer.php';?>
        
